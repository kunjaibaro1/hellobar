'use strict'

const Hello = require('hello')

class HelloTemplatesController extends Hello.Controller {

}

module.exports = HelloTemplatesController
