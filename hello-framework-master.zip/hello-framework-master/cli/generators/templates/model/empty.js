'use strict'

const Hello = require('hello')

class Template extends Hello.Model {

}

module.exports = Template
