'use strict'

const app = require('../app')

module.exports = app.context.db
