'use strict'

module.exports = {

}
