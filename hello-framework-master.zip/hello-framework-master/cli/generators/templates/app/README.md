# HelloRawTemplate

## Installation

```
yarn setup
```

or

```
yarn install
```

## Running

```
yarn start
```

## Testing

```
yarn test
```
