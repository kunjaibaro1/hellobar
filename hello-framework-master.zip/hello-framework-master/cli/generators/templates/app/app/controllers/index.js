'use strict'

const Hello = require('hello')

module.exports = Hello.Index(__dirname)
