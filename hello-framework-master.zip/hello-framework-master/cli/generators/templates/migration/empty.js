'use strict'

async function up (knex) {

}

async function down (knex) {

}

module.exports = {
  up,
  down
}
