'use strict'

module.exports = {
  App: require('./app'),
  Controller: require('./controller'),
  Migration: require('./migration'),
  Model: require('./model')
}
