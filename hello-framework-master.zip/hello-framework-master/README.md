# Hello 👋

Write less. Ship more.

[![Build Status](https://img.shields.io/travis/hello-js/hello/master.svg)](https://travis-ci.org/hello-js/hello)
[![Coverage Status](https://img.shields.io/coveralls/hello-js/hello.svg)](https://coveralls.io/github/hello-js/hello)
[![Dependency Status](https://img.shields.io/david/hello-js/hello.svg)](https://david-dm.org/hello-js/hello)
[![Standard - JavaScript Style Guide](https://img.shields.io/badge/code%20style-standard-brightgreen.svg)](http://standardjs.com/)

## Installation

Hello is available via `yarn` and `npm`.  To install, simply run:

```
yarn add hello
```

## Testing

```
yarn test
```
