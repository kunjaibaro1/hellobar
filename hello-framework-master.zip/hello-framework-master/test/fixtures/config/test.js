'use strict'

module.exports = {
  file: 'test.js',
  test: 'loaded',
  arrays: ['test'],
  objects: {
    test: true
  }
}
