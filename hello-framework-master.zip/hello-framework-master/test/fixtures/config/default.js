'use strict'

module.exports = {
  file: 'default.js',
  default: 'loaded',
  arrays: ['default'],
  objects: {
    default: true
  }
}
