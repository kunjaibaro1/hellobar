'use strict'

module.exports = {
  file: 'test.local.js',
  local: 'loaded',
  arrays: ['local'],
  objects: {
    local: true
  }
}
